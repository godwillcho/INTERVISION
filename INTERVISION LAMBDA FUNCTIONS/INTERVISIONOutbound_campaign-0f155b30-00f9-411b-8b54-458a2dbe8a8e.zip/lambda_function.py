import json
import boto3
client = boto3.client('connect')

def lambda_handler(event, context):
    #print(event)
    update_contact_attributes(event)
    return {
        'statusCode': 200,
        'body': json.dumps(f'Success.')
    }
    
def questions():
    questions_used = {
        'Q1' : ["How did you hear about us?<break time='0.5s'/>", ["Email <break time='0.5s'/>", "SMS <break time='0.5s'/>", "Internet advert <break time='0.5s'/>", "Press <break time='0.5s'/>", "Recommendation from an acquaintance <break time='0.5s'/>"]],
        'Q2' : ["What did you consult with InterVision? <break time='0.5s'/>", ["Account status <break time='0.5s'/>", "Investment Report <break time='0.5s'/>", "Benefit Information <break time='0.5s'/>", "Press <break time='0.5s'/>", "Information about Intervision <break time='0.5s'/>"]],
        'Q3' : ["How Long have you been a Customer with InterVision? <break time='0.5s'/>", ["1 Year <break time='0.5s'/>", " 2 years <break time='0.5s'/>", "3 or more years <break time='0.5s'/>"]],}
    return questions_used
    
    
def update_contact_attributes(event):
    questions_used = questions()
    
    #  Attributes = {
    #     'loop_control':event['Attributes']['loop_control'],
    #     'questions': event['Attributes']['questions'],
    #     'question_control_index': event['Attributes']['question_control_index']
    # }
    
    loop_index = int(event['Details']['ContactData']['Attributes']['loop_control'])
    
    number_of_questions = len(questions_used)   # determines how many loops will be made.
    answer_bank = []
    question_number = []   # Holds the question number to be used
    question_number.append(f"Q{loop_index}")
    answer_bank.append(questions_used[question_number[0]][0])
    for value in question_number:
        question_array = questions_used[f"{value}"][1]  # Extracts possible answers
        i = 1
        for data in question_array:
            answer_bank.append(f"{i},{data}")
            i += 1
    question_presented =  '\n'.join((answer_bank))    # Question to be sent to the flow
    
    if int(loop_index) <= number_of_questions:
        loop_index += 1
        update_contact_func(event,'loop_control', loop_index)
        update_contact_func(event, 'questions', question_presented)
        update_contact_func(event,'question_control_index', number_of_questions)
  
def update_contact_func(event, attribute, attribute_value):
    attribute_name = attribute
    data = event['Details']['ContactData']['InstanceARN']
    extract_instance_id = data[data.rfind('/') + 1 : len(data)]  # extracts the instance id
    response = client.update_contact_attributes(
        InitialContactId=event['Details']['ContactData']['InitialContactId'],
        InstanceId= f'{extract_instance_id}',
        Attributes={
            f'{attribute_name}': str(attribute_value) # updates stated attributes
            })