import json
import boto3

client = boto3.client('connect')

def lambda_handler(event, context):
    response = client.list_hours_of_operations(
    InstanceId='61d5230b-3e41-4bfb-bd3a-33c209aaf98f',
    MaxResults=123
    )
    print(response)
    # days_of_operation_data = reporting(event, 'InterVision Hours of Operation')
    # attribute = "hours_of_operation"
    # attribute_value = f"{days_of_operation_data}"
    # update_contact_func(event, attribute, attribute_value)  # updates a contact attribute with hours of operation values
    # print(days_of_operation_data)
    return {
        'statusCode': 200
        #'report': days_of_operation_data
    }
    
def extract_data(data): # data is event data from connect
    contact_id = data['Details']['ContactData']['ContactId']
    instance_ARN = data['Details']['ContactData']['InstanceARN']
    event_type = None
    
    # Extracts instance_id
    indexx = instance_ARN.index("/")
    index_value = indexx + 1
    instance_id = instance_ARN[index_value:]  # Extracts instance id
    
    return [contact_id,event_type, instance_id, instance_ARN]

def extract_hours_of_operation(event):
    # Gets a summary of hours of operation without details
    operation = []
    operation_id = []
    data = extract_data(event)
    instance_idd = f'{data[2]}'
    response = client.list_hours_of_operations(
    InstanceId=instance_idd,
    MaxResults=123
    )
    hours_of_operation_list = response['HoursOfOperationSummaryList']
    for hours_operation in hours_of_operation_list:
        operation.append(hours_operation['Name'])
        operation_id.append(hours_operation['Id'])
    return [operation, operation_id, instance_idd]
    
def describe_hours_of_operation(event, hours_of_operation_name):
    # describes the hours of operation
    summary_data = []
    data = extract_hours_of_operation(event)
    operation_names = data[0]
    operation_ids = data[1]
    if hours_of_operation_name in operation_names:
        index_value = operation_names.index(f"{hours_of_operation_name}")
        selected_operation_id = f'{operation_ids[index_value]}'
        response = client.describe_hours_of_operation(
        InstanceId=f'{data[2]}',
        HoursOfOperationId=f"{selected_operation_id}"
        )
        hours_operation_name  = response['HoursOfOperation']['Name']
        hours_operation_time_zone  = response['HoursOfOperation']['TimeZone']
        hours_operation_config  = response['HoursOfOperation']['Config']
        return [1, hours_operation_name, hours_operation_time_zone, hours_operation_config]
    else:
        return [0]

def extract_days_with_details(event, hours_of_operation_name):
    data = describe_hours_of_operation(event, hours_of_operation_name)
    
    # Used for ordering day values when selection is done not following usual order
    x = ["MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY"]
    y = [] # day values obtained from program
    p = []  # program complete values
    z = [] #control array
    T = [] # desired day order
    
    if data[0] == 1:
        time_zone = data[2]
        day_details = data[3]
        
        # extracts and cleans data obtained from api call
        for day_data in day_details:
            day_value = day_data['Day']
            start_time = f"{day_data['StartTime']['Hours']} {day_data['StartTime']['Minutes']}"
            end_time = f"{day_data['EndTime']['Hours']} {day_data['EndTime']['Minutes']}"
            
            total_start_time = day_data['StartTime']['Hours'] + day_data['StartTime']['Minutes']
            total_end_time = day_data['EndTime']['Hours'] + day_data['EndTime']['Minutes']
            
            if total_start_time < 12:
                start_time = f"{start_time} AM"
            else:
                start_time = f"{start_time} PM"
            if total_end_time < 12:
                end_time = f"{end_time} AM"
            else:
                end_time = f"{end_time} PM"
            complete_time = f"<prosody rate='medium'><break time='1s'/>{day_value}<break/></prosody> from <prosody rate='slow'>{start_time} through {end_time}</prosody>"
            y.append(day_value)
            p.append(complete_time)
            
        # puts values in acceptable day order
        try:
            for value in x:
                if value in y:
                    z.append(y.index(value))
            for value in z:
                T.append(p[value])
        except ValueError:
            pass
        return [1, time_zone, T]
    else:
        return [0, 0]

def reporting(event, hours_of_operation_name):
    reporting_data = []
    data = extract_days_with_details(event, hours_of_operation_name)
    if data[0] == 1:
        reporting_data.append(f"Hours of operation is in {data[1]} time zone")
        reporting_data.append('\n'.join((data[2])))
        pushed_data = '\n'.join((reporting_data))
        return pushed_data
    else:
         pushed_data = "No data available"
         return pushed_data
        
def update_contact_func(event, attribute, attribute_value):
    attribute_name = attribute
    data = event['Details']['ContactData']['InstanceARN']
    extract_instance_id = data[data.rfind('/') + 1 : len(data)]  # extracts the instance id
    response = client.update_contact_attributes(
        InitialContactId=event['Details']['ContactData']['InitialContactId'],
        InstanceId= f'{extract_instance_id}',
        Attributes={
            f'{attribute_name}': str(attribute_value) # updates stated attributes
            })

        
        
    