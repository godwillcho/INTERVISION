import json
import boto3

client = boto3.client('connect')

def lambda_handler(event, context):
    phone_numbers = phone_number()
    for number in phone_numbers:
        data = outbound_call(number)
    return {
        'statusCode': 200,
        'body': json.dumps('Success')
    }

def outbound_call(phone_number):
    data = campaign_data(phone_number)
    outbound_name = data[0]
    destination_number = data[1]
    contact_flow_id = data[2]
    instance_id = data[3]
    queue_name = data[4]
    campaign_id = data[5]
    response = client.start_outbound_voice_contact(
        Name=f'{outbound_name}',
        DestinationPhoneNumber=f"{destination_number}",
        ContactFlowId=f"{contact_flow_id}",
        InstanceId=f"{instance_id}",
        QueueId=f'{queue_name}',
        CampaignId=f'{campaign_id}',
        TrafficType='GENERAL'
        )
    return response
    
def campaign_data(phone_number):
    outbound_name = "Banking_outbound_campaign"
    destination_number = f"{phone_number}"
    contact_flow_id = "bc850f4d-0c83-4919-a3af-350d74d839c5"
    instance_id = "4f787401-0d6f-4200-86db-9d9e1862dd6e"
    queue_name = "922683f0-b584-44ba-9238-d6ccb9b1c9d0"
    campaign_id = "85048980-421e-4a32-b58a-b74e95fe0de2"
    return [outbound_name,destination_number,contact_flow_id,instance_id,queue_name,campaign_id]
    
def phone_number():
    list = ["+17373357652","+2107632342"]
    return list
    
