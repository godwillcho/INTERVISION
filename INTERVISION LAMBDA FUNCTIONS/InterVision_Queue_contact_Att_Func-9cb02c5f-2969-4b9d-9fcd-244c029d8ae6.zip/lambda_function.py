import json
import boto3
import os
import botocore.exceptions

client = boto3.client('connect')


def lambda_handler(event, context):
    instance_id = "1849df04-e6e3-4ee0-ba9a-60f9367efcf6"
    list_of_queues = list_queues(event)
    list_names = list_of_queues[0]
    list_arns = list_of_queues[1]
    
    extracted_standard_arn_in_order = []
    extracted_callback_arn_in_order = []
    
    # list used queue names
    STANDARD_QUEUES = ["CloudServices", "ContactCenterServices", "CyberSecurityService", "DataAndGenerative_AI", "EnterpriseManagement", "GeneralQuestions"]
    CALL_BACK_QUEUES = ["DTMF_CALLBACK_CLOUD", "DTMF_CALLBACK_CONTACTCENTER", "DTMF_CALLBACK_CYBERSECURITY", "DTMF_CALLBACK_DATA_AI","DTMF_CALLBACK_ENTERPRISE_MANAGEMENT", "DTMF_CALLBACK_GENERAL"]
    
    for queue in STANDARD_QUEUES:
        index = list_names.index(queue)
        extracted_standard_arn_in_order.append(list_arns[int(index)])
        
    for queue in CALL_BACK_QUEUES:
        index = list_names.index(queue)
        extracted_callback_arn_in_order.append(list_arns[int(index)])
    
    control = int(event['Details']['Parameters']['control4'])             # controls which arn to select based on parameter value
    contact_attribute_name_to_use = ["SelectedQueue", "QUEUE_NUMBER", "lambda_invoked"]
    
    selected_standard_arn = extracted_standard_arn_in_order[control]
    update_contact_func(event,contact_attribute_name_to_use[0], selected_standard_arn)   # creates contact attribute for queue name selected
    print(selected_standard_arn)
    
    selected_callback_arn = extracted_callback_arn_in_order[control]
    update_contact_func(event,contact_attribute_name_to_use[1], selected_callback_arn)   # creates contact attribute for queue name selected
    print(selected_callback_arn)
    
    update_contact_func(event,contact_attribute_name_to_use[2], 0)   # creates contact attribute for flow control
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
    
def update_contact_func(event, attribute, attribute_value):
    """
    creates or updates a contact attribute
    """
    attribute_name = attribute
    data = event['Details']['ContactData']['InstanceARN']
    extract_instance_id = data[data.rfind('/') + 1 : len(data)]  # extracts the instance id
    response = client.update_contact_attributes(
        InitialContactId=event['Details']['ContactData']['InitialContactId'],
        InstanceId= f'{extract_instance_id}',
        Attributes={
            f'{attribute_name}': str(attribute_value) # updates stated attributes
            })
    return response

def list_queues(event):
    instance_id = connect_parameters(event)[1]     # gets the instance id
    queue_names = []
    queue_arn = []
    queue_id = []
    response = client.list_queues(
        InstanceId=f'{instance_id}',
        QueueTypes=['STANDARD'],
        MaxResults=123
        )
    QueueList = response['QueueSummaryList']
    queue_statistic = {}
    for queue in QueueList:
        queue_names.append(queue['Name'])
        queue_arn.append(queue['Arn'])
        queue_id.append(queue['Id'])
        
    return [queue_names,queue_arn,queue_id]
    
def connect_parameters(event):
    arnn = event['Details']['ContactData']['InstanceARN']
    instance_id = arnn[arnn.rfind('/') + 1 : len(arnn)]  # extracts the instance id
    return [arnn, instance_id]
