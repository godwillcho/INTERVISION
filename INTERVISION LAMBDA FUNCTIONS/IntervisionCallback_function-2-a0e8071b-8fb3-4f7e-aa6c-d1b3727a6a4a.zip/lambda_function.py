import json
import boto3
import os
import botocore.exceptions
client = boto3.client('translate')
client2 = boto3.client('connect')
client3 = boto3.client('s3')

def lambda_handler(event, context):
    # Edit environment variable for other languages
    # Gets language code from environment variables
    source_lang_code = os.environ.get('source_lang_code')
    target_lang_code = os.environ.get('destination_lang_code')
    
    
    data = text_to_translate(source_lang_code,target_lang_code)   # Translates given text in a list
    
    print(data)
    

# Creates contact Attributes for both languages
    data_languages = data_to_translate_1()
    lang_1_contact_attributes = data_languages[1]
    lang_2_contact_attributes = data_languages[2]
    
    # creates contact attributes for first language
    language_control = event['Details']['Parameters']['language_control']
    if data[0] == 1:
        index_1 = 0
        # creates contact attribute for first language
        for Att in lang_1_contact_attributes:
            if language_control == '1':
                text_value = data[1][index_1]
                updating1= update_contact_func(event,Att, text_value)
                print("testing", language_control)
                index_1 += 1
            
        index_2 = 0 
    # creates contact attribute for second language
        for Att1 in lang_2_contact_attributes:
            if language_control == '2':
                text_value1 = data[2][index_2]
                updating1= update_contact_func(event,Att1, text_value1)
                index_2 += 1
    return {
        'statusCode': 200,
        'body': json.dumps('Success')
    }
    
    
    
def data_to_translate_1():
    # data from file to translate
    # Number of attributes should match number of data
    

    data =  ['is the phone number. To confirm, enter 1. for another Phone number, enter 2',"We will call you back."]
    # contact attribute names can be edited for use case
    lang1_contact_attributes = ["prompt_callback_2", "prompt_confirm"]   # contact attribute name for language 1
    lang2_contact_attributes = ["prompt_callback", "selectionn"]   # contact attribute name for language 2
    if len(data) == len(lang1_contact_attributes) and len(data) == len(lang2_contact_attributes):
        return [data, lang1_contact_attributes, lang2_contact_attributes]
    

def text_to_translate(source_lang_code, target_lang_code):   # text_to_translate is a list of text
    """
    translates original text to target language
    0: implies failure
    1: implies success
    """
    original_text = data_to_translate_1()[0]  # list of text to be translated
    
    translated_text = []
    try:
        if len(original_text) == 0:
            return [0]
        elif len(original_text) > 0:
            for text in original_text:
                translation = compile_translation(text ,source_lang_code,target_lang_code)   # translates the text
                translated_text.append(translation)
            return [1, original_text, translated_text]
    except ValueError:
        return [0]
    except TypeError:
        return [0]
            
            
def compile_translation(text_to_translate_en,source_lang_code, target):
   
    # Text translated from English to target language or languages.
    translated_text = translate_text(source_lang_code,target , text_to_translate_en)['TranslatedText']
    modified_text = f"{translated_text}"
    return modified_text

def translate_text(source_lang_code, target_lang_code, text_to_translate):
    "Translates from source language to destination language"
    response = client.translate_text(
    Text=f'{text_to_translate}',
    SourceLanguageCode=f'{source_lang_code}',
    TargetLanguageCode=f'{target_lang_code}',
    Settings={
        'Formality': 'FORMAL',
        'Profanity': 'MASK',
        'Brevity': 'ON'})
    return response
    
def update_contact_func(event, attribute, attribute_value):
    """
    creates or updates a contact attribute
    """
    attribute_name = attribute
    data = event['Details']['ContactData']['InstanceARN']
    extract_instance_id = data[data.rfind('/') + 1 : len(data)]  # extracts the instance id
    response = client2.update_contact_attributes(
        InitialContactId=event['Details']['ContactData']['InitialContactId'],
        InstanceId= f'{extract_instance_id}',
        Attributes={
            f'{attribute_name}': str(attribute_value) # updates stated attributes
            })
    return response