import json

def lambda_handler(event, context):
    question_number = int(event['Details']['ContactData']['Attributes']['loop_control']) - 1
    answer = event['Details']['Parameters']['answer_value']
    value_to_be_saved = f'Q{question_number} : {answer}'
    print(value_to_be_saved)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
