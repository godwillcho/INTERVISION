import json

def lambda_handler(event, context):
    verification_data = verification(event)
    
    return {
        'selection': f'{verification_data[2]}',
        'verification': f'{verification_data[0]}',
        "employee_name": f'{verification_data[1]}'
    }
    
    
def verification(event):
    employee_data = employee_numbers()
    selection = event['Details']['Parameters']['selection']
    id_number = event['Details']['Parameters']['id_number']
    if len(id_number) == 6:
        if id_number in employee_data[1]:
            index_id = employee_data[1].index(id_number)
            employee_name = employee_data[0][index_id]
            return [1, employee_name,selection]
        else:
            return [0,0,0]
    elif len(id_number) != 6:
        return [2,0,0]
        


def employee_numbers():
    employee = ["Cho Godwill", "Marc-Dariel Cho", "Marie Cho"]
    employee_id = ["123456", "123465","123467"]
    return [employee, employee_id]